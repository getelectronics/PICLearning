winnt_xp    (Windows Vista Windows Vista x64
                     Windows XP    Windows XP x64   Windows 2000
                     Windows Server 2003   Windows Server 2003 x64)
win98_me (Windows 98    Windows ME)

